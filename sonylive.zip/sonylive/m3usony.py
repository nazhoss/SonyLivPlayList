import requests
import json

PAGE_URL = "https://apiv3.sonyliv.com/AGL/3.5/A/ENG/WEB/IN/MH/PAGE-V2/39379_24064"

def fetch_json(url):
    """Fetch JSON safely from a URL."""
    try:
        res = requests.get(url, timeout=10)
        res.raise_for_status()
        return res.json()
    except Exception as e:
        print(f"❌ Error fetching {url}: {e}")
        return None


def find_sports_items(obj):
    """Recursively search for any sports-related metadata entries."""
    found = []
    if isinstance(obj, dict):
        if "genres" in obj and any(
            sport.lower() in [g.lower() for g in obj["genres"]]
            for sport in ["Cricket", "Football", "Tennis", "Hockey", "Kabaddi", "Wrestling", "Sports"]
        ):
            found.append(obj)
        for v in obj.values():
            found.extend(find_sports_items(v))
    elif isinstance(obj, list):
        for item in obj:
            found.extend(find_sports_items(item))
    return found


def extract_match_info(item):
    """Extract all useful fields from a single sports entry."""
    meta = item.get("metadata", item)
    emf = meta.get("emfAttributes", {})

    return {
        "title": meta.get("title"),
        "contentId": meta.get("contentId"),
        "genres": meta.get("genres", []),
        "isLive": meta.get("isLive") or meta.get("isOnAir"),
        "isUpcoming": str(meta.get("upcoming")).lower() == "true",
        "logo": (
            meta.get("landscape_thumb")
            or emf.get("landscape_thumb")
            or meta.get("masthead_logo_rectangualar")
            or meta.get("masthead_large_v3")
            or emf.get("masthead_large_v3")
        ),
    }


def build_m3u(live_items):
    """Generate M3U playlist text for all live matches."""
    lines = ["#EXTM3U"]
    for item in live_items:
        title = item["title"] or "Unknown Match"
        logo = item.get("logo", "")
        group = ",".join(item.get("genres", [])) or "Sports"
        video_url = item.get("videoURL", "")

        if video_url:
            lines.append(
                f'#EXTINF:-1 tvg-logo="{logo}" group-title="sonyliv-{group}", {title}\n{video_url}'
            )
    return "\n".join(lines)


def main():
    data = fetch_json(PAGE_URL)
    if not data:
        return

    sports_items = find_sports_items(data)
    if not sports_items:
        print(json.dumps({"error": "No sports items found"}, indent=2))
        return

    output = []
    live_items = []

    for item in sports_items:
        match = extract_match_info(item)
        status = "live" if match["isLive"] else "upcoming" if match["isUpcoming"] else "unknown"
        match["status"] = status

        # Fetch video URL for live streams
        if status == "live" and match["contentId"]:
            video_api = f"https://apiv2.sonyliv.com/AGL/4.7/A/ENG/WEB/IN/MH/CONTENT/VIDEOURL/VOD/{match['contentId']}/freepreview"
            video_json = fetch_json(video_api)
            if video_json and "resultObj" in video_json:
                match["videoURL"] = video_json["resultObj"].get("videoURL")
                live_items.append(match)

        output.append(match)

    # Save JSON
    with open("sonyliv-event.json", "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    # Save M3U for live streams
    if live_items:
        playlist_text = build_m3u(live_items)
        with open("sonyliv-event.m3u", "w", encoding="utf-8") as f:
            f.write(playlist_text)
        print("✅ Saved: sonyliv-event.json and sonyliv-event.m3u")
    else:
        print("⚠️ No live items found. Saved only sonyliv-event.json")


if __name__ == "__main__":
    main()
