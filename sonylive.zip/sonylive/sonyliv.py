import requests

PAGE_URL = "https://apiv3.sonyliv.com/AGL/3.5/A/ENG/WEB/IN/MH/PAGE-V2/39379_24064"

def fetch_json(url):
    """Fetch JSON safely from a URL."""
    try:
        res = requests.get(url, timeout=10)
        res.raise_for_status()
        return res.json()
    except Exception as e:
        print(f"❌ Error fetching {url}: {e}")
        return None


def find_sports_items(obj):
    """Recursively search for any sports-related metadata entries."""
    found = []
    if isinstance(obj, dict):
        # Look for 'genres' that contain known sports keywords
        if "genres" in obj and any(
            sport.lower() in [g.lower() for g in obj["genres"]]
            for sport in ["Cricket", "Football", "Tennis", "Hockey", "Kabaddi", "Wrestling", "Sports"]
        ):
            found.append(obj)
        for v in obj.values():
            found.extend(find_sports_items(v))
    elif isinstance(obj, list):
        for item in obj:
            found.extend(find_sports_items(item))
    return found


def extract_match_info(item):
    """Extract all useful fields from a single sports entry."""
    meta = item.get("metadata", item)
    emf = meta.get("emfAttributes", {})

    return {
        "title": meta.get("title"),
        "contentId": meta.get("contentId"),
        "genres": meta.get("genres", []),
        "isLive": meta.get("isLive") or meta.get("isOnAir"),
        "isUpcoming": str(meta.get("upcoming")).lower() == "true",
        "logo": (
            meta.get("landscape_thumb")
            or emf.get("landscape_thumb")
            or meta.get("masthead_logo_rectangualar")
            or meta.get("masthead_large_v3")
            or emf.get("masthead_large_v3")
        ),
    }


def main():
    data = fetch_json(PAGE_URL)
    if not data:
        return

    sports_items = find_sports_items(data)
    if not sports_items:
        print("⚠️ No sports items found.")
        return

    for i, item in enumerate(sports_items, 1):
        match = extract_match_info(item)
        status = "live" if match["isLive"] else "upcoming" if match["isUpcoming"] else "unknown"

        print(f"\n⚽ SPORT #{i}")
        print(f"🏷️ Title: {match['title']}")
        print(f"🆔 Content ID: {match['contentId']}")
        print(f"📺 Logo: {match['logo']}")
        print(f"📡 Status: {status}")
        print(f"🎯 Genres: {match['genres']}")

        # If it's live, get the live link
        if status == "live" and match["contentId"]:
            video_api = f"https://apiv2.sonyliv.com/AGL/4.7/A/ENG/WEB/IN/MH/CONTENT/VIDEOURL/VOD/{match['contentId']}/freepreview"
            video_json = fetch_json(video_api)
            if video_json and "resultObj" in video_json:
                video_url = video_json["resultObj"].get("videoURL")
                print(f"🎥 Live Video URL: {video_url}")


if __name__ == "__main__":
    main()
